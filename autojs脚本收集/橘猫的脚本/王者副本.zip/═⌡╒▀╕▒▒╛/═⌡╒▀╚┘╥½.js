auto.waitFor();
requestScreenCapture(true);
var 次数 = dialogs.input("本轮刷多少次", "50");
sleep(1000);

for (let i = 0; i < 次数; i++) {
    var 随机 = random(-3, 3);
    var 时间 = random(300, 1000);
    do {
        var 闯关 = images.read("./闯关.jpg");
        var 闯 = findImage(captureScreen(), 闯关, {
            region: [0, 50],
            threshold: 0.7
        })
        if (闯) {
            sleep(时间);
            click(闯.x + 闯关.width / 2 + 随机, 闯.y + 闯关.height / 2 + 随机)
        } else {
            sleep(1000);
        }
    } while (!闯);
    sleep(50000);
    do {
        var 点击屏幕 = images.read("./点击屏幕.jpg");
        var 点击 = findImage(captureScreen(), 点击屏幕, {
            region: [0, 50],
            threshold: 0.7
        })
        if (点击) {
            sleep(时间);
            click(点击.x + 点击屏幕.width / 2 + 随机, 点击.y + 点击屏幕.height / 2 + 随机)
        } else {
            sleep(1000);
        }
    } while (!点击);
    sleep(3000);
    do {
        var 再次挑战 = images.read("./再次挑战.jpg");
        var 再次 = findImage(captureScreen(), 再次挑战, {
            region: [0, 50],
            threshold: 0.7
        })
        if (再次) {
            sleep(时间);
            click(再次.x + 再次挑战.width / 2 + 随机, 再次.y + 再次挑战.height / 2 + 随机)
        } else {
            sleep(1000);
        }
    } while (!再次);
    sleep(3000);
}
toastLog("完成" + 次数 + "次");